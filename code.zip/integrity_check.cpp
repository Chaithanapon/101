#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
#include <cstdio>
#include <functional> 

using namespace std;
using HashType = size_t; 

const vector<string> critical_files = {
    "/etc/passwd", 
    "/etc/shadow",
    "/etc/sudoers",
    "/usr/bin/ssh",
    "/bin/bash"
};

HashType calculate_file_hash(const string& filename) {
    ifstream file(filename, ios::binary);
    if (!file.is_open()) {
        // ไม่ใช่ข้อผิดพลาดร้ายแรงถ้าไฟล์ไม่อยู่
        return 0; 
    }
    stringstream buffer;
    buffer << file.rdbuf();
    return hash<string>{}(buffer.str());
}

void check_integrity() {
    cout << "--- Starting File Integrity Check ---" << endl;
    
    for (const string& file : critical_files) {
        HashType current_hash = calculate_file_hash(file);
        // ⚠️ ในการใช้งานจริง: ต้องใช้ Hash ที่คำนวณไว้ก่อนหน้า (Reference Hash)
        // เพื่อเปรียบเทียบกับ current_hash
        // HashType reference_hash = ... (Load from secure database)
        
        // สำหรับ PoC
        cout << "[INFO] Checked: " << file << " (Hash: " << current_hash << ")" << endl;
    }
    cout << "--- Integrity Check Complete ---" << endl;
}

int main() {
    check_integrity();
    return 0;
}