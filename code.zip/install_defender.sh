#!/bin/bash
# สคริปต์สำหรับติดตั้งและเปิดใช้งาน AI Defender ทั้งหมด

# ตรวจสอบสิทธิ์ Root
if [ "$(id -u)" != "0" ]; then
   echo "🚨 ต้องรันสคริปต์นี้ด้วยสิทธิ์ root (ใช้ sudo)" 1>&2
   exit 1
fi

BASE_DIR="/opt/ai-defender"
SERVICE_NAME="ai-defender"

echo "=========================================================="
echo "🚀 AI DEFENSE SYSTEM INSTALLATION"
echo "=========================================================="

# 1. สร้างโฟลเดอร์ที่จำเป็น
echo "[STEP 1] Setting up directory structure..."
mkdir -p $BASE_DIR/ai_models
mkdir -p /etc/systemd/system

# 2. คัดลอกไฟล์ทั้งหมดไปยัง BASE_DIR
echo "[STEP 2] Copying all defense scripts..."
cp prepare_models.py $BASE_DIR/
cp external_sensor.py $BASE_DIR/
cp init_harden.sh $BASE_DIR/
cp defender_loop.sh $BASE_DIR/
cp integrity_check.cpp $BASE_DIR/
chmod +x $BASE_DIR/*.sh # กำหนดสิทธิ์รัน

# 3. รัน Prepare Models (สร้างไฟล์ .joblib)
echo "[STEP 3] Running prepare_models.py to create AI models..."
python3 $BASE_DIR/prepare_models.py

# 4. คอมไพล์ C++ Code
echo "[STEP 4] Compiling C++ code..."
g++ $BASE_DIR/integrity_check.cpp -o $BASE_DIR/integrity_check
if [ $? -ne 0 ]; then
    echo "❌ C++ compilation failed. Aborting."
    exit 1
fi

# 5. สร้างไฟล์ Systemd Service Unit
echo "[STEP 5] Creating Systemd Service Unit..."

cat << EOF > /etc/systemd/system/$SERVICE_NAME.service
[Unit]
Description=AI Defense Orchestrator
After=network.target network-online.target tor@default.service

[Service]
# รัน init_harden.sh ก่อนเพื่อตั้งค่า Firewall และ Tor
ExecStartPre=/bin/bash $BASE_DIR/init_harden.sh
# รัน defender_loop.sh ที่จะควบคุมการทำงานต่อเนื่องของ Agent และ Self-Heal
ExecStart=/bin/bash $BASE_DIR/defender_loop.sh
WorkingDirectory=$BASE_DIR
Restart=always
User=root

[Install]
WantedBy=multi-user.target
EOF

# 6. โหลดและเปิดใช้งาน Service
echo "[STEP 6] Enabling and Starting AI Defender Service..."
systemctl daemon-reload
systemctl enable $SERVICE_NAME.service
systemctl start $SERVICE_NAME.service

echo "=========================================================="
echo "✅ DEPLOYMENT COMPLETE!"
echo "AI Defender จะทำงานโดยอัตโนมัติทุกครั้งที่เปิดเครื่อง"
echo "ตรวจสอบสถานะ: sudo systemctl status $SERVICE_NAME"
echo "=========================================================="