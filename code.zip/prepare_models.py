import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from joblib import dump
import os

MODEL_PATH = "ai_models/"
os.makedirs(MODEL_PATH, exist_ok=True)

print("--- Preparing Pre-trained AI Models ---")

# 1. การสร้างข้อมูล
np.random.seed(42)
X_normal = np.random.randn(1000, 3) * [5, 1, 10]
X_attack_scan = np.random.randn(50, 3) * [50, 5, 2] + [100, 10, 50]
X = np.vstack([X_normal, X_attack_scan])
y = np.array([0] * 1000 + [1] * 50) 

# 2. Train Scaler & Save
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
dump(scaler, MODEL_PATH + "scaler.joblib")
print("✅ Scaler trained and saved.")

# 3. Train A1 (Isolation Forest) & Save
a1_model = IsolationForest(contamination=0.05, random_state=42, n_jobs=-1)
a1_model.fit(X_scaled)
dump(a1_model, MODEL_PATH + "a1_anomaly.joblib")
print("✅ A1 Model (Isolation Forest) trained and saved.")

# 4. Train A2 (Random Forest) & Save
a2_model = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
a2_model.fit(X_scaled, y)
dump(a2_model, MODEL_PATH + "a2_classifier.joblib")
print("✅ A2 Model (Random Forest) trained and saved.")

print("--- Preparation Complete. Ready to Deploy ---")