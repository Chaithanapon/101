import requests
import json
import logging
import time
import subprocess
import numpy as np

# 1. Configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s - EXTERNAL SENSOR - %(message)s')
EXTERNAL_AI_API = "http://api.external-ai-defense.com/v1/threat_analysis" 

# 2. Proxy Settings (Tor)
PROXY_SETTINGS = {
    'http': 'socks5h://127.0.0.1:9050',
    'https': 'socks5h://127.0.0.1:9050'
}

def collect_network_flow_data():
    """จำลองการรวบรวมข้อมูล Network Flow (Low CPU usage)"""
    np.random.seed(int(time.time() * 1000) % 10000) # Random seed based on time
    data_points = {
        'timestamp': time.time(),
        'source_ip': f'203.0.113.{np.random.randint(5, 255)}', # Random IP
        'dest_port': np.random.choice([80, 443, 22]),
        'connections': np.random.randint(1, 100),
        'duration_avg': np.random.uniform(0.1, 5.0)
    }
    return data_points

def send_to_ai_and_receive_action(flow_data):
    """ส่งข้อมูล Flow ไปยัง External AI Service และรับคำสั่งตอบสนอง"""
    try:
        response = requests.post(EXTERNAL_AI_API, json=flow_data, proxies=PROXY_SETTINGS, timeout=15)
        response.raise_for_status()
        ai_response = response.json()
        
        action = ai_response.get('action', 'MONITOR')
        threat_type = ai_response.get('threat_type', 'N/A')
        
        if action == 'BLOCK_IP':
            target_ip = flow_data['source_ip']
            # รันคำสั่ง IPTABLES ด้วยทรัพยากรที่น้อยที่สุด
            subprocess.run(['sudo', 'iptables', '-I', 'INPUT', '-s', target_ip, '-j', 'DROP'], check=True)
            subprocess.run(['sudo', 'netfilter-persistent', 'save'], check=True)
            
            logging.critical(f"🔥 EXTERNAL AI COMMAND: Auto-blocked IP {target_ip} ({threat_type})")
            return True, threat_type

        logging.info(f"AI Status: {action}. (Threat: {threat_type})")
        return False, threat_type

    except requests.exceptions.RequestException as e:
        logging.error(f"❌ Failed to communicate with External AI Service (via Tor): {e}")
        return False, "COMMUNICATION_ERROR"
    except Exception as e:
        logging.error(f"❌ Processing Error: {e}")
        return False, "INTERNAL_ERROR"

if __name__ == "__main__":
    logging.info("External AI Sensor is now active (Zero-Resource Mode).")
    
    while True:
        network_data = collect_network_flow_data()
        send_to_ai_and_receive_action(network_data)
        time.sleep(5)