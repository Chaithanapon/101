#!/bin/bash
# Script สำหรับ Initial Hardening และ Zero Trust Firewall

INTERFACE="eth0" 
TOR_PORT="9050"
SSH_PORT="22" 
TRUSTED_LOCAL_SUBNET="192.168.1.0/24" 

echo "[INFO] Applying Kernel Hardening..."
sysctl -w net.ipv4.conf.all.rp_filter=1 > /dev/null
sysctl -w net.ipv4.tcp_syncookies=1 > /dev/null
sysctl -p > /dev/null

echo "[INFO] Configuring ZERO TRUST Firewall..."
sudo iptables -F; sudo iptables -X; sudo iptables -t nat -F

# นโยบายเริ่มต้น: บล็อกทุกอย่าง
sudo iptables -P INPUT DROP
sudo iptables -P FORWARD DROP
sudo iptables -P OUTPUT DROP 

# อนุญาตสิ่งที่จำเป็น
sudo iptables -A INPUT -i lo -j ACCEPT
sudo iptables -A OUTPUT -o lo -j ACCEPT
sudo iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# อนุญาต SSH จาก Local Network
sudo iptables -A INPUT -p tcp --dport $SSH_PORT -s $TRUSTED_LOCAL_SUBNET -j ACCEPT 

# บังคับใช้ TOR (อนุญาตเฉพาะ Localhost 9050 ขาออก)
sudo iptables -A OUTPUT -p tcp -d 127.0.0.1 --dport $TOR_PORT -j ACCEPT
sudo iptables -A OUTPUT -p udp -d 127.0.0.1 --dport 53 -j ACCEPT 

sudo netfilter-persistent save
echo "✅ Firewall configuration saved."

# Start Tor
sudo service tor start
echo "✅ Tor service started."