#!/bin/bash
# สคริปต์หลักที่รันเป็น Daemon เพื่อควบคุมความเสถียรของ Defender

LOG_FILE="/var/log/defender_loop.log"
PYTHON_SCRIPT="external_sensor.py"
C_EXEC="./integrity_check"

echo "[INFO] Starting AI Defense Orchestration..."

# 1. รัน AI Defender (Python) ในพื้นหลัง
nohup python3 $PYTHON_SCRIPT >> $LOG_FILE 2>&1 &
PYTHON_PID=$!
echo "✅ AI Defender started with PID: $PYTHON_PID"

# 2. Main Stability Loop
while true; do
    
    # A. ตรวจสอบความสมบูรณ์ของไฟล์ (C++ Integrity Check) - รันทุก 5 นาที
    if (( $(date +%M) % 5 == 0 )); then
        $C_EXEC >> $LOG_FILE 2>&1
    fi

    # B. ตรวจสอบสถานะ Firewall 
    if ! sudo iptables -L OUTPUT -n | grep "DROP" | grep -q "0.0.0.0/0"; then
        echo "[ALERT] Firewall rules corrupted! Re-applying init_harden.sh" >> $LOG_FILE
        sudo bash init_harden.sh >> $LOG_FILE 2>&1
    fi
    
    # C. ตรวจสอบสถานะ Tor Service
    if ! service tor status | grep -q "active (running)"; then
        echo "[ALERT] Tor service is down! Restarting..." >> $LOG_FILE
        sudo service tor start >> $LOG_FILE 2>&1
    fi

    # D. ตรวจสอบสถานะ Python Sensor
    if ! ps -p $PYTHON_PID > /dev/null; then
        echo "[ALERT] External Sensor crashed! Restarting..." >> $LOG_FILE
        nohup python3 $PYTHON_SCRIPT >> $LOG_FILE 2>&1 &
        PYTHON_PID=$!
    fi

    sleep 60 
done